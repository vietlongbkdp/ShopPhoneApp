package controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import services.ProductImportService;
import services.ProductService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "productImportController", urlPatterns = "/product-import")
public class ProductImportController extends HttpServlet {
    private ProductService productService;

    private ProductImportService productImportService;

    public void init() throws ServletException {
        productService = new ProductService();
        productImportService = new ProductImportService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) {
            action = "";
        }
        switch (action) {
            case "create":
                showCreate(req, resp);
                break;
            case "update":
                showUpdate(req, resp);
                break;
            case "delete":
                delete(req, resp);
                break;
            default:
                showList(req, resp);
        }

    }


    private void showList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String pageString = req.getParameter("page");
        if (pageString == null) {
            pageString = "1";
        }
        req.setAttribute("page", productImportService.findAll(Integer.parseInt(pageString), req.getParameter("search")));
//        req.setAttribute("productImports", productImportService.findAll());
        req.setAttribute("search", req.getParameter("search"));
        req.setAttribute("message", req.getParameter("message"));
        req.getRequestDispatcher("product-import/index.jsp").forward(req, resp);
    }


    private void showCreate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var products = productService.fillAll();
        req.setAttribute("products", products);
        req.setAttribute("productsJSON", new ObjectMapper().writeValueAsString(products));
        req.getRequestDispatcher("product-import/create.jsp").forward(req, resp);
    }

    private void showUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        req.setAttribute("productImport", productImportService
                .findById(Integer.parseInt(req.getParameter("id"))));
        var products = productService.fillAll();
        req.setAttribute("products", products);
        req.setAttribute("productsJSON", new ObjectMapper().writeValueAsString(products));
        req.getRequestDispatcher("product-import/edit.jsp").forward(req, resp);
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        productImportService.delete(Integer.parseInt(req.getParameter("id")));
        resp.sendRedirect("/product-import?message=Deleted");
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) {
            action = "";
        }
        switch (action) {
            case "create":
                create(req, resp);
                break;
            case "update":
                update(req, resp);
                break;

        }
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        productImportService.update(req);
        resp.sendRedirect("/product-import?message=Updated Successfully");
    }


    private void create(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        productImportService.create(req);
        resp.sendRedirect("/product-import?message=Created Successfully");
    }
}
