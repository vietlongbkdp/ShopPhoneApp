package models;

public enum EStatus {
    CONFIRMING, CONFIRMED,CANCELED
}
