package models;

public enum EGender {
    MALE, FEMALE, OTHER;
}
